# Rudra Keyboard — Android Studio starter project

This is a source project for a functional starter custom Android keyboard. It includes:
- Android `InputMethodService`
- QWERTY key layout and basic typing/deletion
- Offline Tarty-inspired, Small Caps, Bubble, Bold Serif and Fraktur mappings
- Toolbar and docked AI panel UI
- Local preferences screen
- API-free ChatGPT/Gemini browser handoff (does not scrape or automatically read provider responses)

## Requirements
- Android Studio with a compatible Android SDK
- JDK 17
- Internet access on first Gradle sync/build to download dependencies

## Build APK
1. Extract this ZIP.
2. Open the `RudraKeyboard` folder in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, from a terminal with Gradle/Android SDK configured:
`gradle assembleDebug`

## Enable keyboard
Install the APK, open Rudra Keyboard, tap **Open input settings**, enable Rudra Keyboard, then select it as the current keyboard.

## Notes
- This is a starter project, not a production-ready Gboard replacement.
- It intentionally does not automate or scrape logged-in ChatGPT/Gemini web sessions.
- AI browser handoff opens the official web experience; users must submit/copy content themselves.
- Google/Firebase sign-in and cloud sync are not configured. Add Firebase project configuration and implement security rules before enabling cloud features.
- Test carefully before using in password fields or other sensitive inputs.

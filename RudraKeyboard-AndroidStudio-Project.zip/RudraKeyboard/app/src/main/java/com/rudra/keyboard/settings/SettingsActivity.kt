package com.rudra.keyboard.settings

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "Rudra Keyboard"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Enable the keyboard in Android settings, then select it from the input method picker."
            textSize = 16f
            setPadding(0, 16, 0, 16)
        })
        root.addView(Button(this).apply {
            text = "Open input settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "Choose keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.showInputMethodPicker()
            }
        })
        root.addView(TextView(this).apply {
            text = "Fonts work offline. AI buttons open the selected provider website; responses are not automatically scraped."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        })
        setContentView(root)
    }
}

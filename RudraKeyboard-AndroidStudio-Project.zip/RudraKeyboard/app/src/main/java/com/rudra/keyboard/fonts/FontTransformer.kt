package com.rudra.keyboard.fonts

object FontTransformer {
    private val tarty = mapOf(
        'a' to "α", 'b' to "в", 'c' to "¢", 'd' to "∂",
        'e' to "є", 'f' to "ƒ", 'g' to "ɢ", 'h' to "н",
        'i' to "ι", 'j' to "נ", 'k' to "κ", 'l' to "ℓ",
        'm' to "м", 'n' to "η", 'o' to "σ", 'p' to "ρ",
        'q' to "զ", 'r' to "я", 's' to "ѕ", 't' to "т",
        'u' to "υ", 'v' to "ν", 'w' to "ω", 'x' to "χ",
        'y' to "γ", 'z' to "ζ"
    )
    private val smallCaps = mapOf(
        'a' to "ᴀ", 'b' to "ʙ", 'c' to "ᴄ", 'd' to "ᴅ",
        'e' to "ᴇ", 'f' to "ꜰ", 'g' to "ɢ", 'h' to "ʜ",
        'i' to "ɪ", 'j' to "ᴊ", 'k' to "ᴋ", 'l' to "ʟ",
        'm' to "ᴍ", 'n' to "ɴ", 'o' to "ᴏ", 'p' to "ᴘ",
        'q' to "ǫ", 'r' to "ʀ", 's' to "ꜱ", 't' to "ᴛ",
        'u' to "ᴜ", 'v' to "ᴠ", 'w' to "ᴡ", 'x' to "x",
        'y' to "ʏ", 'z' to "ᴢ"
    )
    private val bubble = mapOf(
        'a' to "ⓐ", 'b' to "ⓑ", 'c' to "ⓒ", 'd' to "ⓓ",
        'e' to "ⓔ", 'f' to "ⓕ", 'g' to "ⓖ", 'h' to "ⓗ",
        'i' to "ⓘ", 'j' to "ⓙ", 'k' to "ⓚ", 'l' to "ⓛ",
        'm' to "ⓜ", 'n' to "ⓝ", 'o' to "ⓞ", 'p' to "ⓟ",
        'q' to "ⓠ", 'r' to "ⓡ", 's' to "ⓢ", 't' to "ⓣ",
        'u' to "ⓤ", 'v' to "ⓥ", 'w' to "ⓦ", 'x' to "ⓧ",
        'y' to "ⓨ", 'z' to "ⓩ"
    )
    private val bold = ('a'..'z').mapIndexed { i, c ->
        c to String(Character.toChars(0x1D41A + i))
    }.toMap()
    private val fraktur = ('a'..'z').mapIndexed { i, c ->
        val cp = when (c) {
            'h' -> 0x1D525
            else -> 0x1D51E + i
        }
        c to String(Character.toChars(cp))
    }.toMap()

    fun transform(text: String, style: FontStyle): String {
        val mapping = when (style) {
            FontStyle.NORMAL -> emptyMap()
            FontStyle.TARTY -> tarty
            FontStyle.SMALL_CAPS -> smallCaps
            FontStyle.BUBBLE -> bubble
            FontStyle.BOLD_SERIF -> bold
            FontStyle.FRAKTUR -> fraktur
        }
        if (mapping.isEmpty()) return text
        return buildString {
            text.forEach { ch ->
                val lower = ch.lowercaseChar()
                val replacement = mapping[lower]
                if (replacement == null) append(ch)
                else if (ch.isUpperCase()) append(replacement.uppercase())
                else append(replacement)
            }
        }
    }
}

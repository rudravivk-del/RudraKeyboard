package com.rudra.keyboard.fonts

enum class FontStyle {
    NORMAL, TARTY, SMALL_CAPS, BUBBLE, BOLD_SERIF, FRAKTUR
}

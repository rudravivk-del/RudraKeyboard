package com.rudra.keyboard.ime

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.provider.Settings
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.rudra.keyboard.databinding.KeyboardViewBinding
import com.rudra.keyboard.fonts.FontStyle
import com.rudra.keyboard.fonts.FontTransformer

class RudraInputMethodService : InputMethodService() {
    private var binding: KeyboardViewBinding? = null
    private var fontStyle = FontStyle.NORMAL
    private var shifted = false
    private var selectedProvider = Provider.CHATGPT

    private enum class Provider { CHATGPT, GEMINI }

    override fun onCreateInputView(): View {
        val b = KeyboardViewBinding.inflate(layoutInflater)
        binding = b
        setupKeys(b)
        setupToolbar(b)
        setupAiPanel(b)
        return b.root
    }

    private fun setupKeys(b: KeyboardViewBinding) {
        val keys = mapOf(
            b.keyQ to "q", b.keyW to "w", b.keyE to "e",
            b.keyR to "r", b.keyT to "t", b.keyY to "y",
            b.keyU to "u", b.keyI to "i", b.keyO to "o",
            b.keyP to "p", b.keyA to "a", b.keyS to "s",
            b.keyD to "d", b.keyF to "f", b.keyG to "g",
            b.keyH to "h", b.keyJ to "j", b.keyK to "k",
            b.keyL to "l", b.keyZ to "z", b.keyX to "x",
            b.keyC to "c", b.keyV to "v", b.keyB to "b",
            b.keyN to "n", b.keyM to "m"
        )
        keys.forEach { (view, value) ->
            view.setOnClickListener { commitKey(if (shifted) value.uppercase() else value) }
        }
        b.keySpace.setOnClickListener { commitKey(" ") }
        b.keyComma.setOnClickListener { commitKey(",") }
        b.keyPeriod.setOnClickListener { commitKey(".") }
        b.keyShift.setOnClickListener { shifted = !shifted }
        b.keyDelete.setOnClickListener { deletePrevious() }
        b.keyEnter.setOnClickListener { sendEnter() }
        b.keySymbols.setOnClickListener {
            // Basic symbol toggle placeholder: insert a question mark.
            commitKey("?")
        }
        b.keyFont.setOnClickListener { cycleFont() }
    }

    private fun setupToolbar(b: KeyboardViewBinding) {
        b.toolbar.keyAi.setOnClickListener { toggleAiPanel() }
        b.toolbar.keyFontToolbar.setOnClickListener { cycleFont() }
        b.toolbar.keySettings.setOnClickListener {
            try {
                val intent = Intent(this, com.rudra.keyboard.settings.SettingsActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (_: Exception) { }
        }
        b.toolbar.keyVoice.setOnClickListener {
            // Voice input depends on the selected system speech/IME provider.
            try {
                requestShowSelf(0)
            } catch (_: Exception) { }
        }
    }

    private fun setupAiPanel(b: KeyboardViewBinding) {
        b.aiPanel.aiChatGpt.setOnClickListener { selectedProvider = Provider.CHATGPT }
        b.aiPanel.aiGemini.setOnClickListener { selectedProvider = Provider.GEMINI }
        b.aiPanel.aiSend.setOnClickListener {
            val url = if (selectedProvider == Provider.CHATGPT)
                "https://chatgpt.com/"
            else "https://gemini.google.com/"
            try {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { }
        }
        b.aiPanel.aiPaste.setOnClickListener {
            val clipboard = getSystemService(ClipboardManager::class.java)
            val clip = clipboard?.primaryClip
            val copied = if (clip != null && clip.itemCount > 0)
                clip.getItemAt(0).coerceToText(this).toString()
            else ""
            if (copied.isNotEmpty()) b.aiPanel.aiResponse.text = copied
        }
        b.aiPanel.aiCopy.setOnClickListener {
            val text = b.aiPanel.aiResponse.text.toString()
            if (text.isNotBlank()) {
                getSystemService(ClipboardManager::class.java)?.setPrimaryClip(
                    ClipData.newPlainText("Rudra AI response", text)
                )
            }
        }
        b.aiPanel.aiInsert.setOnClickListener {
            val text = b.aiPanel.aiResponse.text.toString()
            if (text.isNotBlank()) currentInputConnection?.commitText(text, 1)
        }
    }

    private fun commitKey(text: String) {
        val connection: InputConnection = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val isPassword = info?.inputType?.let {
            val variation = it and android.text.InputType.TYPE_MASK_VARIATION
            val cls = it and android.text.InputType.TYPE_MASK_CLASS
            cls == android.text.InputType.TYPE_CLASS_TEXT &&
                (variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                 variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                 variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
        } ?: false
        val output = if (isPassword) text else FontTransformer.transform(text, fontStyle)
        connection.commitText(output, 1)
        shifted = false
    }

    private fun deletePrevious() {
        currentInputConnection?.deleteSurroundingTextInCodePoints(1, 0)
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun cycleFont() {
        fontStyle = when (fontStyle) {
            FontStyle.NORMAL -> FontStyle.TARTY
            FontStyle.TARTY -> FontStyle.SMALL_CAPS
            FontStyle.SMALL_CAPS -> FontStyle.BUBBLE
            FontStyle.BUBBLE -> FontStyle.BOLD_SERIF
            FontStyle.BOLD_SERIF -> FontStyle.FRAKTUR
            FontStyle.FRAKTUR -> FontStyle.NORMAL
        }
        binding?.keyFont?.text = when (fontStyle) {
            FontStyle.NORMAL -> "Aa"
            FontStyle.TARTY -> "Tα"
            FontStyle.SMALL_CAPS -> "ᴬᴀ"
            FontStyle.BUBBLE -> "ⓐ"
            FontStyle.BOLD_SERIF -> "𝐚"
            FontStyle.FRAKTUR -> "𝔞"
        }
    }

    private fun toggleAiPanel() {
        val panel = binding?.aiPanel?.root ?: return
        panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        // Keep the selected font, but do not retain editor-specific composing state.
    }

    override fun onDestroy() {
        binding = null
        super.onDestroy()
    }
}

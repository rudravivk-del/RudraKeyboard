package com.rudra.keyboard

import com.rudra.keyboard.fonts.FontStyle
import com.rudra.keyboard.fonts.FontTransformer
import org.junit.Assert.assertEquals
import org.junit.Test

class FontTransformerTest {
    @Test fun normalPreservesText() {
        assertEquals("hello 123!", FontTransformer.transform("hello 123!", FontStyle.NORMAL))
    }
    @Test fun tartyMapsLetters() {
        assertEquals("αв¢∂є", FontTransformer.transform("abcde", FontStyle.TARTY))
    }
    @Test fun smallCapsMapsLetters() {
        assertEquals("ʜᴇʟʟᴏ", FontTransformer.transform("hello", FontStyle.SMALL_CAPS))
    }
    @Test fun bubbleKeepsPunctuation() {
        assertEquals("ⓗⓘ !", FontTransformer.transform("hi !", FontStyle.BUBBLE))
    }
    @Test fun nonLatinAndEmojiStayIntact() {
        assertEquals("नमस्ते 😀", FontTransformer.transform("नमस्ते 😀", FontStyle.SMALL_CAPS))
    }
}
